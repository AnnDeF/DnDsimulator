import { Component, Output} from '@angular/core';
import { TabComponent } from './tab.component';
import { EventEmitter } from 'events';

@Component({
  selector: 'tabs',
  template:  `
  <ul>
  <li *ngFor="let tab of tabs">
    <a href="#" (click)="selectTab(tab)">{{tab.tabTitle}}</a>
  </li>
</ul>
<ng-content></ng-content>
`
})
export class TabsComponent{
  tabs:TabComponent[] = [];
  @Output() selected = new EventEmitter();
  
  addTab(tab:TabComponent) {
    if (!this.tabs.length) {
      tab.selected = true;
    }
    this.tabs.push(tab);
  }
  
  selectTab(tab:TabComponent) {
    this.tabs.map((tab) => {
      tab.selected = false;
    })
    tab.selected = true;
    this.selected.emit({selectedTab: tab});    
  }


}
