import { Component, OnInit, Input } from '@angular/core';
import { TabsComponent } from './tabs.component';

@Component({
  selector: 'tab',
  template: `
  <div [hidden]="!selected">
  <ng-content></ng-content>
</div>
`
})
export class TabComponent implements OnInit {
  private selected:boolean;

  @Input() tabTitle;

  constructor(private tabsComponent: TabsComponent) { }

  ngOnInit() {
    this.tabsComponent.addTab(this);
  }

}
